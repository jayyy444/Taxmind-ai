import streamlit as st

MODEL_GROQ      = "llama-3.3-70b-versatile"
MODEL_ANTHROPIC = "claude-sonnet-4-20250514"

SYSTEM_TEMPLATE = """You are TaxMind AI, a professional Indian tax advisor specialising in FY 2026 tax planning.
You have deep expertise in the Income Tax Act, GST, ITR filing, advance tax, and investment planning for Indian residents.

Current user context:
- Name: {name}
- Employment type: {employment_type}
- Income bracket: {income_bracket}
- Preferred tax regime: {preferred_regime}
- Total income recorded: Rs. {total_income:,.0f}
- Total expenses recorded: Rs. {total_expenses:,.0f}
- Estimated net tax payable: Rs. {net_tax:,.0f}

Instructions:
- Always give advice relevant to FY 2026 Indian tax rules.
- Be concise, accurate, and professional.
- Do not use emojis.
- Do not speculate. If you are unsure, say so and recommend consulting a CA.
- Cite relevant sections of the Income Tax Act where applicable.
- If the user asks about saving tax, focus on legal avenues valid under their chosen regime.
"""


def _build_system_prompt(context: dict) -> str:
    return SYSTEM_TEMPLATE.format(
        name=context.get("name", "User"),
        employment_type=context.get("employment_type", "Not specified"),
        income_bracket=context.get("income_bracket", "Not specified"),
        preferred_regime=context.get("preferred_regime", "new"),
        total_income=context.get("total_income", 0),
        total_expenses=context.get("total_expenses", 0),
        net_tax=context.get("net_tax", 0),
    )


def _get_groq_key() -> str:
    """Return GROQ API key from secrets, or empty string if not set/placeholder."""
    try:
        key = st.secrets.get("GROQ_API_KEY", "")
        if key and key != "your-groq-api-key-here":
            return key
    except Exception:
        pass
    return ""


def _chat_via_groq(user_message: str, history: list, system_prompt: str) -> str:
    """Try Groq API and return response string."""
    from groq import Groq
    client = Groq(api_key=_get_groq_key())
    messages = [{"role": "system", "content": system_prompt}]
    messages.extend(history)
    messages.append({"role": "user", "content": user_message})
    response = client.chat.completions.create(
        model=MODEL_GROQ,
        messages=messages,
        max_tokens=1000,
        temperature=0.4,
    )
    return response.choices[0].message.content.strip()


def _chat_via_anthropic(user_message: str, history: list, system_prompt: str) -> str:
    """Fallback to Anthropic API."""
    import requests
    messages = []
    for msg in history:
        messages.append({"role": msg["role"], "content": msg["content"]})
    messages.append({"role": "user", "content": user_message})

    resp = requests.post(
        "https://api.anthropic.com/v1/messages",
        headers={"Content-Type": "application/json"},
        json={
            "model": MODEL_ANTHROPIC,
            "max_tokens": 1000,
            "system": system_prompt,
            "messages": messages,
        },
        timeout=30,
    )
    resp.raise_for_status()
    data = resp.json()
    return data["content"][0]["text"].strip()


def chat(user_message: str, history: list[dict], context: dict) -> str:
    """
    Send a message and return the assistant reply.
    Tries Groq first; falls back to Anthropic if Groq key is missing/invalid.
    """
    system_prompt = _build_system_prompt(context)
    groq_key = _get_groq_key()

    if groq_key:
        try:
            return _chat_via_groq(user_message, history, system_prompt)
        except Exception:
            pass  # fall through to Anthropic

    # Anthropic fallback
    try:
        return _chat_via_anthropic(user_message, history, system_prompt)
    except Exception as e:
        raise RuntimeError(
            f"Both AI backends failed. Error: {str(e)}\n"
            "Please check your internet connection or set GROQ_API_KEY in .streamlit/secrets.toml"
        ) from e
